#!/bin/bash

#현재 서비스하고 있는 WAS 포트 번호 읽어오기
#CURRENT_PORT=$(cat /etc/nginx/conf.d/service-url.inc | grep -Po '[0-9]+' | tail -1)
CURRENT_PORT=$(sudo cat /etc/nginx/conf.d/service-url.inc | grep -Po '[0-9]+' | tail -1)
TARGET_PORT=0

echo "> Current port of running WAS is ${CURRENT_PORT}."

# 현재 포트가 8081이면 새로운 WAS 띄울 타켓은 8082, 혹은 그 반대!
if [ ${CURRENT_PORT} -eq 8081 ]; then
  TARGET_PORT=8082
elif [ ${CURRENT_PORT} -eq 8082 ]; then
  TARGET_PORT=8081
else
  echo "> No WAS is connected to nginx!!"
fi

TARGET_PID=$( sudo lsof -Fp -i TCP:${TARGET_PORT} | grep -Po 'p[0-9]+' | grep -Po '[0-9]+')
# 만약 타겟포트에도 WAS 떠 있다면 kill하고 새롭게 띄우기
if [ ! -z "${TARGET_PID}" ]; then
  echo "> Kill WAS running at ${TARGET_PORT}."
  sudo kill ${TARGET_PID}
fi

#마지막&는 프로세스가 백그라운드로 실행되도록 해준다.
nohup java -jar -Dserver.port=${TARGET_PORT} /home/ec2-user/app/deploy/naegahama-0.0.1-SNAPSHOT.jar > /home/ec2-user/app/deploy/nohupFolder/nohup$(date +%Y)-$(date +%m)-$(date +%d)-$(date +%H):$(date +%M).out 2>&1 &
echo "> Now new WAS runs at ${TARGET_PORT}."
exit 0
