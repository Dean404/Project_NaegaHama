package com.hanghae.naegahama.initial;

import java.util.ArrayList;
import java.util.Arrays;

public class Category {

    public static ArrayList<String> category = new ArrayList<>(
            Arrays.asList("cook","health","knowledge","create","visit","job","pet","fashion","consult","device","life","etc")
    );

}
