package com.hanghae.naegahama.ex;

public class AnswerNotFoundException extends RuntimeException{
    public AnswerNotFoundException(String message) {
        super(message);
    }
}
