package com.hanghae.naegahama.domain;

public enum RankStatus {
    up, down, stay
}
