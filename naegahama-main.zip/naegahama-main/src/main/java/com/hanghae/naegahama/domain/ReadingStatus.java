
package com.hanghae.naegahama.domain;

public enum ReadingStatus {
    Y, N
}