package com.hanghae.naegahama.dto.MyPage;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class MyAchievementDto
{
    private int[] achievement = new int[8];
}
