package com.hanghae.naegahama.ex;

public class AnswerFileNotFoundException extends RuntimeException{
    public AnswerFileNotFoundException(String message) {
        super(message);
    }
}
