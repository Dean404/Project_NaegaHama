package com.hanghae.naegahama.ex;

public class IllegalPostDeleteUserException extends RuntimeException {
    public IllegalPostDeleteUserException(String message) {
        super(message);
    }
}
