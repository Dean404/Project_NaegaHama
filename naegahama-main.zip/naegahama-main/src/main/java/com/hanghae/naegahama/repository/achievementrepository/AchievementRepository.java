package com.hanghae.naegahama.repository.achievementrepository;

import com.hanghae.naegahama.domain.Achievement;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AchievementRepository extends JpaRepository<Achievement, Long>
{

}
