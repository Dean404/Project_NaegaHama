package com.hanghae.naegahama.ex;

public class IllegalPostUpdateUserException extends RuntimeException{
    public IllegalPostUpdateUserException(String message) {
        super(message);
    }
}
